import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { createBrowserRouter, createRoutesFromElements, Route, RouterProvider } from 'react-router-dom'
import Layout from "./Layout.jsx"
import Home from './components/Home/Home.jsx'
// import Contact from './contact/contact.jsx'
// import User from './User/User.jsx'
import Login from './components/LogIn/Login.jsx'
import Register from './components/Register/Register.jsx'
import ViewAllTrains from './components/Users/ViewAllTrains.jsx'
import Dashboard from './components/Users/Dashboard.jsx'
import NewBooking from './components/Users/NewBooking.jsx'
import ViewAllBookingsForm from './components/Users/ViewAllBookingsForm.jsx'
import UserBookings from './components/Users/UserBookings.jsx'
import CancelBookingForm from './components/Users/CancelBookingForm.jsx'
import AdminDashboard from './components/Admin/AdminDashboard.jsx'
import RetrieveUserById from './components/Admin/RetrieveUserById.jsx'
import AllUsers from './components/Admin/AllUsers.jsx'
import BookingByTrainNo from './components/Admin/BookingByTrainNo.jsx'
import AllBookings from './components/Admin/AllBookings.jsx'
import AddTrain from './components/Admin/AddTrain.jsx'
import GetTrainDetails from './components/Admin/GetTrainDetails.jsx'
import DeleteTrain from './components/Admin/DeleteTrain.jsx'



//another way of creating the router for pass in routerProvider
const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element= {<Layout/>}>
      <Route path='' element = {<Home/>}/>
      <Route path='login' element = {<Login/>}/>
      <Route path='register' element = {<Register/>}/>
      <Route path='viewAllTrains' element = {<ViewAllTrains/>}/>
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/new-booking" element={<NewBooking />} />
      <Route path="/view-bookings" element={<ViewAllBookingsForm />} />
      <Route path="/bookings/:email" element={<UserBookings />} />
      <Route path="/cancel-booking" element={<CancelBookingForm />} />
      <Route path="/admin/dashboard" element={<AdminDashboard />} />
      <Route path="/admin/user-by-id" element={<RetrieveUserById />} />
      <Route path="/admin/all-users" element={<AllUsers />} />
      <Route path="/admin/booking-by-train" element={<BookingByTrainNo />} />
      <Route path="/admin/all-bookings" element={<AllBookings />} />
      <Route path="/admin/add-train" element={<AddTrain />} />
      <Route path="/admin/train-by-number" element={<GetTrainDetails />} />
      <Route path="/admin/delete-train" element={<DeleteTrain />} />

    </Route>
  )
)


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router}/>
  </StrictMode>,
)
