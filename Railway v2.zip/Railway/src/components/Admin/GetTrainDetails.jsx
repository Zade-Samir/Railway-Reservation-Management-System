import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function GetTrainDetails() {
  const [trainNumber, setTrainNumber] = useState("");
  const [trainDetails, setTrainDetails] = useState(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!trainNumber) {
      setError("Please enter a train number.");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8084/api/train/${trainNumber}`);
      if (!response.ok) throw new Error("No train found with this number.");
      const data = await response.json();
      setTrainDetails(data);
      setError("");
    } catch (err) {
      setError(err.message);
      setTrainDetails(null);
    }
  };

  const handleBackToDashboard = () => {
    navigate("/admin/dashboard");
  };

  return (
    <div className="p-8 max-w-full mx-auto bg-white">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Get Train Details</h1>
        <button
          onClick={handleBackToDashboard}
          className="py-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 text-sm focus:ring-4 focus:ring-gray-300"
        >
          Back to Dashboard
        </button>
      </div>

      <form onSubmit={handleSubmit} className="mb-6">
        <label className="block text-lg font-medium mb-2 text-gray-800" htmlFor="trainNumber">
          Enter Train Number:
        </label>
        <input
          type="text"
          id="trainNumber"
          value={trainNumber}
          onChange={(e) => setTrainNumber(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded mb-4 focus:ring-4 focus:ring-gray-300"
          placeholder="Train Number"
        />
        <button
          type="submit"
          className="py-2 px-4 bg-orange-700 text-white rounded hover:bg-orange-800 text-sm focus:ring-4 focus:ring-orange-300"
        >
          Fetch Train Details
        </button>
      </form>

      {error && <p className="text-red-600 mb-4">{error}</p>}

      {trainDetails && (
        <div className="overflow-x-auto">
          <table className="min-w-full border border-gray-300 bg-white rounded shadow-sm">
            <thead className="bg-gray-100 text-left">
              <tr>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Train Number</th>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Train Name</th>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Source</th>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Destination</th>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Departure Time</th>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Arrival Time</th>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Total Seats</th>
                <th className="py-2 px-4 border border-gray-300 text-gray-800">Available Seats</th>
              </tr>
            </thead>
            <tbody>
              <tr className="hover:bg-gray-50">
                <td className="py-2 px-4 border border-gray-300">{trainDetails.trainNumber}</td>
                <td className="py-2 px-4 border border-gray-300">{trainDetails.trainName}</td>
                <td className="py-2 px-4 border border-gray-300">{trainDetails.source}</td>
                <td className="py-2 px-4 border border-gray-300">{trainDetails.destination}</td>
                <td className="py-2 px-4 border border-gray-300">{trainDetails.departureTime}</td>
                <td className="py-2 px-4 border border-gray-300">{trainDetails.arrivalTime}</td>
                <td className="py-2 px-4 border border-gray-300">{trainDetails.totalSeats}</td>
                <td className="py-2 px-4 border border-gray-300">{trainDetails.availableSeats}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
