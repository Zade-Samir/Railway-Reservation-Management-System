import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AllUsers() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:8081/api/users")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch users");
        return res.json();
      })
      .then((data) => {
        setUsers(data);
      })
      .catch((err) => {
        setError(err.message);
      });
  }, []);

  const handleBackToDashboard = () => {
    navigate("/admin/dashboard"); // Adjust route as needed
  };

  return (
    <div className="w-full min-h-screen bg-white px-4 py-10">
      <div className="max-w-7xl mx-auto p-5 border border-gray-200 rounded shadow">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-orange-700">All Registered Users</h1>
          <button
            onClick={handleBackToDashboard}
            className="py-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 text-sm focus:ring-4 focus:ring-orange-300"
          >
            Back to Dashboard
          </button>
        </div>

        {error && <p className="text-red-600 text-center mb-4">{error}</p>}

        <div className="overflow-x-auto">
          <table className="min-w-full border border-gray-400 bg-white rounded shadow-sm">
            <thead className="bg-gray-100">
              <tr className="text-left text-gray-700 font-semibold">
                <th className="py-3 px-4 border border-gray-300">ID</th>
                <th className="py-3 px-4 border border-gray-300">Full Name</th>
                <th className="py-3 px-4 border border-gray-300">Email</th>
                <th className="py-3 px-4 border border-gray-300">Role</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50 text-left">
                  <td className="py-3 px-4 border border-gray-300">{user.id}</td>
                  <td className="py-3 px-4 border border-gray-300">{user.fullName}</td>
                  <td className="py-3 px-4 border border-gray-300">{user.email}</td>
                  <td className="py-3 px-4 border border-gray-300">{user.role || "No role assigned"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
