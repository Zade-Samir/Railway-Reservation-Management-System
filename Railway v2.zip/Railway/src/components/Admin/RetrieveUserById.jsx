import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function RetrieveUserById() {
  const [userId, setUserId] = useState("");
  const [userData, setUserData] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!userId) {
      setError("Please enter a user ID.");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8081/api/users/${userId}`);
      if (!response.ok) {
        throw new Error("User not found");
      }
      const data = await response.json();
      setUserData(data);
      setError(null);
    } catch (err) {
      setError(err.message);
      setUserData(null);
    }
  };

  const handleBackToDashboard = () => {
    navigate("/admin/dashboard");
  };

  return (
    <div className="p-8 max-w-6xl mx-auto bg-white">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-orange-700">Retrieve User by ID</h1>
        <button
          onClick={handleBackToDashboard}
          className="py-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 text-sm focus:ring-4 focus:ring-gray-300"
        >
          Back to Dashboard
        </button>
      </div>

      {error && <p className="text-red-600 mb-4">{error}</p>}

      {userData ? (
        <div className="max-w-2xl mx-auto p-5 border border-gray-300 rounded shadow-sm bg-gray-50">
          <div className="space-y-3">
            <p className="text-base font-medium text-gray-700">
              <strong>ID:</strong> {userData.id}
            </p>
            <p className="text-base font-medium text-gray-700">
              <strong>Name:</strong> {userData.fullName}
            </p>
            <p className="text-base font-medium text-gray-700">
              <strong>Email:</strong> {userData.email}
            </p>
            <p className="text-base font-medium text-gray-700">
              <strong>Role:</strong> {userData.role || "No role assigned"}
            </p>
            <button
              onClick={handleBackToDashboard}
              className="mt-4 bg-orange-700 hover:bg-orange-800 text-white px-4 py-1.5 rounded focus:ring-4 focus:ring-orange-300 transition"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="max-w-2xl mx-auto p-5 border border-gray-300 rounded shadow-sm bg-gray-50  space-x-2">
          <div className="space-y-5">
            <label className="block font-semibold mb-1 text-gray-800">Enter User ID</label>
            <input
              type="text"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-4 focus:ring-orange-300"
            />
            <button
              type="submit"
              className="w-full bg-orange-700 text-white py-2 rounded hover:bg-orange-800 focus:ring-4 focus:ring-orange-300 transition"
            >
              Retrieve User
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
