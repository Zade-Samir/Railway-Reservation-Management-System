import React from "react";
import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <div className="bg-white border border-gray-200 p-8 max-w-6xl mx-auto rounded-xl shadow-md">
      <h1 className="text-3xl font-bold text-center text-orange-700 mb-10">
        Admin Dashboard
      </h1>

      {/* Section: Register */}
      <section className="mb-10">
        <h2 className="text-2xl font-semibold mb-4 border-b border-gray-300 pb-2">
          📋 Register Section
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <button
            onClick={() => navigate("/admin/user-by-id")}
            className="bg-orange-700 text-white hover:bg-orange-800 focus:ring-4 focus:ring-orange-300 font-semibold py-4 px-6 rounded-lg shadow-md transition"
          >
            🔍 Retrieve a User by ID
          </button>

          <button
            onClick={() => navigate("/admin/all-users")}
            className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-semibold py-4 px-6 rounded-lg shadow-md transition border border-gray-200"
          >
            📄 View All Registered Users
          </button>
        </div>
      </section>

      {/* Section: Booking */}
      <section className="mb-10">
        <h2 className="text-2xl font-semibold mb-4 border-b border-gray-300 pb-2">
          🧾 Booking Section
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <button
            onClick={() => navigate("/admin/booking-by-train")}
            className="bg-orange-700 text-white hover:bg-orange-800 focus:ring-4 focus:ring-orange-300 font-semibold py-4 px-6 rounded-lg shadow-md transition"
          >
            🚆 Get Bookings by Train Number
          </button>

          <button
            onClick={() => navigate("/admin/all-bookings")}
            className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-semibold py-4 px-6 rounded-lg shadow-md transition border border-gray-200"
          >
            📚 View All Bookings
          </button>
        </div>
      </section>

      {/* Section: Train */}
      <section>
        <h2 className="text-2xl font-semibold mb-4 border-b border-gray-300 pb-2">
          🚄 Train Section
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <button
            onClick={() => navigate("/admin/add-train")}
            className="bg-orange-700 text-white hover:bg-orange-800 focus:ring-4 focus:ring-orange-300 font-semibold py-4 px-6 rounded-lg shadow-md transition"
          >
            ➕ Add a New Train
          </button>

          <button
            onClick={() => navigate("/admin/train-by-number")}
            className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-semibold py-4 px-6 rounded-lg shadow-md transition border border-gray-200"
          >
            🔎 Get Train Details
          </button>
        </div>

        {/* Centering Delete Train Button */}
        <div className="flex justify-center mt-6">
          <button
            onClick={() => navigate("/admin/delete-train")}
            className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-semibold py-4 px-6 rounded-lg shadow-md transition border border-gray-200"
          >
            ❌ Delete a Train
          </button>
        </div>
      </section>
    </div>
  );
}
