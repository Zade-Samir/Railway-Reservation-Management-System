import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function BookingBytrainNumber() {
  const [trainNumber, setTrainNumber] = useState("");
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!trainNumber) {
      setError("Please enter a train number.");
      return;
    }

    try {
      const token = localStorage.getItem("token"); // adjust if you're using sessionStorage
      const response = await fetch(`http://localhost:8083/api/booking/train/${trainNumber}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) throw new Error("No bookings found for this train number or unauthorized.");

      const data = await response.json();
      setBookings(data);
      setError("");
    } catch (err) {
      setError(err.message);
      setBookings([]);
    }
  };

  const handleBackToDashboard = () => {
    navigate("/admin/dashboard"); // Adjust route as needed
  };

  return (
    <div className="w-full min-h-screen bg-white px-4 py-10">
      <div className="max-w-7xl mx-auto p-5 border border-gray-200 rounded shadow">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-orange-700">Get Bookings by Train Number</h1>
          <button
            onClick={handleBackToDashboard}
            className="py-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 text-sm focus:ring-4 focus:ring-orange-300"
          >
            Back to Dashboard
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mb-6  space-x-2">
          <label className="block text-lg font-medium mb-2" htmlFor="trainNumber">
            Enter Train Number:
          </label>
          <input
            type="text"
            id="trainNumber"
            value={trainNumber}
            onChange={(e) => setTrainNumber(e.target.value)}
            className="w-1/2 p-2 border border-gray-300 rounded mb-4 focus:ring-4 focus:ring-orange-300"
            placeholder="Train Number"
          />
          <button
            type="submit"
            className="py-2 px-4 bg-orange-700 text-white rounded hover:bg-orange-800 text-sm focus:ring-4 focus:ring-orange-300"
          >
            Fetch Bookings
          </button>
        </form>

        {error && <p className="text-red-600 mb-4">{error}</p>}

        {bookings.length > 0 && (
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-300 bg-white rounded shadow-sm">
              <thead className="bg-gray-100 text-left">
                <tr>
                  <th className="py-2 px-4 border border-gray-300">Booking ID</th>
                  <th className="py-2 px-4 border border-gray-300">User Email</th>
                  <th className="py-2 px-4 border border-gray-300">Train Number</th>
                  <th className="py-2 px-4 border border-gray-300">Train Name</th>
                  <th className="py-2 px-4 border border-gray-300">Journey Date</th>
                  <th className="py-2 px-4 border border-gray-300">Source</th>
                  <th className="py-2 px-4 border border-gray-300">Destination</th>
                  <th className="py-2 px-4 border border-gray-300">Tickets</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((booking) => (
                  <tr key={booking.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border border-gray-300">{booking.id}</td>
                    <td className="py-2 px-4 border border-gray-300">{booking.userEmail}</td>
                    <td className="py-2 px-4 border border-gray-300">{booking.trainNumber}</td>
                    <td className="py-2 px-4 border border-gray-300">{booking.trainName}</td>
                    <td className="py-2 px-4 border border-gray-300">{booking.journeyDate}</td>
                    <td className="py-2 px-4 border border-gray-300">{booking.source}</td>
                    <td className="py-2 px-4 border border-gray-300">{booking.destination}</td>
                    <td className="py-2 px-4 border border-gray-300">{booking.numberOfTickets}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
