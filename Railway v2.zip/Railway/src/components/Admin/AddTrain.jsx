import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AddTrain() {
  const [trainData, setTrainData] = useState({
    trainNumber: "",
    trainName: "",
    source: "",
    destination: "",
    departureTime: "",
    arrivalTime: "",
    totalSeats: "",
    availableSeats: "",
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTrainData({ ...trainData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const {
      trainNumber,
      trainName,
      source,
      destination,
      departureTime,
      arrivalTime,
      totalSeats,
      availableSeats,
    } = trainData;

    if (
      !trainNumber ||
      !trainName ||
      !source ||
      !destination ||
      !departureTime ||
      !arrivalTime ||
      !totalSeats ||
      !availableSeats
    ) {
      setError("Please fill in all fields.");
      return;
    }

    try {
      const token = localStorage.getItem("token"); // Or sessionStorage if used
      const response = await fetch("http://localhost:8084/api/train/add", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(trainData),
      });

      if (!response.ok) throw new Error("Failed to add new train.");
      setSuccess("Train added successfully.");
      setError("");
      setTrainData({
        trainNumber: "",
        trainName: "",
        source: "",
        destination: "",
        departureTime: "",
        arrivalTime: "",
        totalSeats: "",
        availableSeats: "",
      });
    } catch (err) {
      setError(err.message);
      setSuccess("");
    }
  };

  const handleBackToDashboard = () => {
    navigate("/admin/dashboard");
  };

  return (
    <div className="p-8 max-w-6xl mx-auto bg-white">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Add a New Train</h1>
        <button
          onClick={handleBackToDashboard}
          className="py-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 text-sm"
        >
          Back to Dashboard
        </button>
      </div>

      <form onSubmit={handleSubmit} className="mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="trainNumber">
              Train Number:
            </label>
            <input
              type="text"
              id="trainNumber"
              name="trainNumber"
              value={trainData.trainNumber}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
              placeholder="Train Number"
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="trainName">
              Train Name:
            </label>
            <input
              type="text"
              id="trainName"
              name="trainName"
              value={trainData.trainName}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
              placeholder="Train Name"
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="source">
              Source:
            </label>
            <input
              type="text"
              id="source"
              name="source"
              value={trainData.source}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
              placeholder="Source"
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="destination">
              Destination:
            </label>
            <input
              type="text"
              id="destination"
              name="destination"
              value={trainData.destination}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
              placeholder="Destination"
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="departureTime">
              Departure Time:
            </label>
            <input
              type="time"
              id="departureTime"
              name="departureTime"
              value={trainData.departureTime}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="arrivalTime">
              Arrival Time:
            </label>
            <input
              type="time"
              id="arrivalTime"
              name="arrivalTime"
              value={trainData.arrivalTime}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="totalSeats">
              Total Seats:
            </label>
            <input
              type="number"
              id="totalSeats"
              name="totalSeats"
              value={trainData.totalSeats}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
              placeholder="Total Seats"
            />
          </div>
          <div>
            <label className="block text-lg font-medium mb-2" htmlFor="availableSeats">
              Available Seats:
            </label>
            <input
              type="number"
              id="availableSeats"
              name="availableSeats"
              value={trainData.availableSeats}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-4 focus:ring-orange-300"
              placeholder="Available Seats"
            />
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            className="py-2 px-6 bg-orange-700 text-white rounded hover:bg-orange-800 focus:ring-4 focus:ring-orange-300"
          >
            Add Train
          </button>
        </div>
      </form>

      {error && <p className="text-red-600 mb-4">{error}</p>}
      {success && <p className="text-green-600 mb-4">{success}</p>}
    </div>
  );
}
