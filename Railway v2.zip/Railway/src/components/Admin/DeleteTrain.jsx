import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function DeleteTrain() {
  const [trainNumber, setTrainNumber] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!trainNumber) {
      setError("Please enter a train number.");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8084/api/train/${trainNumber}`, {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Failed to delete the train. Ensure the train exists.");

      setMessage("Train deleted successfully.");
      setError("");  // Clear any previous errors
    } catch (err) {
      setError(err.message);
      setMessage("");  // Clear any previous success messages
    }
  };

  const handleBackToDashboard = () => {
    navigate("/admin/dashboard");
  };

  return (
    <div className="p-8 max-w-full mx-auto bg-white">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Delete a Train</h1>
        <button
          onClick={handleBackToDashboard}
          className="py-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 text-sm focus:ring-4 focus:ring-gray-300"
        >
          Back to Dashboard
        </button>
      </div>

      <form onSubmit={handleSubmit} className="mb-6 space-x-2">
        <label className="block text-lg font-medium mb-2 text-gray-800" htmlFor="trainNumber">
          Enter Train Number to Delete:
        </label>
        <input
          type="text"
          id="trainNumber"
          value={trainNumber}
          onChange={(e) => setTrainNumber(e.target.value)}
          className="w-1/2 p-2 border border-gray-300 rounded mb-6 focus:ring-4 focus:ring-gray-300"
          placeholder="Train Number"
        />
        <button
          type="submit"
          className="py-2 px-4 bg-red-600 text-white rounded hover:bg-red-700 text-sm focus:ring-4 focus:ring-orange-300"
        >
          Delete Train
        </button>
      </form>

      {error && <p className="text-red-600 mb-4">{error}</p>}
      {message && <p className="text-green-600 mb-4">{message}</p>}
    </div>
  );
}
