import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AllBookings() {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAllBookings = async () => {
      try {
        const token = localStorage.getItem("token"); // Or sessionStorage if used
        const response = await fetch("http://localhost:8083/api/booking/all", {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) throw new Error("Failed to fetch bookings.");
        const data = await response.json();
        setBookings(data);
        setError("");
      } catch (err) {
        setError(err.message);
        setBookings([]);
      }
    };

    fetchAllBookings();
  }, []);

  const handleBackToDashboard = () => {
    navigate("/admin/dashboard");
  };

  return (
    <div className="p-8 max-w-full mx-auto bg-white">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">All Bookings</h1>
        <button
          onClick={handleBackToDashboard}
          className="py-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 text-sm focus:ring-4 focus:ring-gray-300"
        >
          Back to Dashboard
        </button>
      </div>

      {error && <p className="text-red-600 mb-4">{error}</p>}

      {bookings.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="min-w-full border border-gray-300 bg-white rounded shadow-sm">
            <thead className="bg-gray-100 text-left">
              <tr>
                <th className="py-2 px-4 border border-gray-300">Booking ID</th>
                <th className="py-2 px-4 border border-gray-300">User Email</th>
                <th className="py-2 px-4 border border-gray-300">Train Number</th>
                <th className="py-2 px-4 border border-gray-300">Train Name</th>
                <th className="py-2 px-4 border border-gray-300">Journey Date</th>
                <th className="py-2 px-4 border border-gray-300">Source</th>
                <th className="py-2 px-4 border border-gray-300">Destination</th>
                <th className="py-2 px-4 border border-gray-300">Tickets</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.id} className="hover:bg-gray-50">
                  <td className="py-2 px-4 border border-gray-300">{booking.id}</td>
                  <td className="py-2 px-4 border border-gray-300">{booking.userEmail}</td>
                  <td className="py-2 px-4 border border-gray-300">{booking.trainNumber}</td>
                  <td className="py-2 px-4 border border-gray-300">{booking.trainName}</td>
                  <td className="py-2 px-4 border border-gray-300">{booking.journeyDate}</td>
                  <td className="py-2 px-4 border border-gray-300">{booking.source}</td>
                  <td className="py-2 px-4 border border-gray-300">{booking.destination}</td>
                  <td className="py-2 px-4 border border-gray-300">{booking.numberOfTickets}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        !error && <p className="text-gray-600">No bookings found.</p>
      )}
    </div>
  );
}
