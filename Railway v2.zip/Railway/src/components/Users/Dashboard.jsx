import React from "react";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const token = localStorage.getItem("authToken");
  const userEmail = localStorage.getItem("userEmail");
  const navigate = useNavigate();

  return (
    <div className="min-h-[50vh] flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-xl bg-white shadow-xl rounded-2xl p-8">
        <h2 className="text-3xl font-extrabold text-center text-gray-800 mb-6">
          🚆 User Dashboard
        </h2>

        <div className="bg-gray-50 p-4 rounded-lg border mb-6">
          <p className="text-gray-700 mb-2">
            <span className="font-semibold">📧 Logged in as:</span> {userEmail}
          </p>
          <p className="text-gray-700 break-all">
            <span className="font-semibold">🔐 Token:</span> {token}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            className="bg-green-600 text-white py-3 rounded-lg shadow hover:bg-green-700 transition duration-300"
            onClick={() => navigate("/new-booking")}
          >
            📝 New Booking
          </button>
          <button
            className="bg-blue-600 text-white py-3 rounded-lg shadow hover:bg-blue-700 transition duration-300"
            onClick={() => navigate("/view-bookings")}
          >
            📄 View Bookings
          </button>
          <button
            className="bg-red-600 text-white py-3 rounded-lg shadow hover:bg-red-700 transition duration-300"
            onClick={() => navigate("/cancel-booking")}
          >
            ❌ Cancel Booking
          </button>
        </div>
      </div>
    </div>
  );
}
