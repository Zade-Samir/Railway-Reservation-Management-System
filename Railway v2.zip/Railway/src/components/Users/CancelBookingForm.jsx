import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function CancelBookingForm() {
  const [bookingId, setBookingId] = useState("");
  const [statusMessage, setStatusMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate(); // useNavigate hook to handle navigation

  const handleCancelBooking = async (e) => {
    e.preventDefault();

    if (!bookingId.trim()) {
      setErrorMessage("Please enter a valid booking ID.");
      return;
    }

    const token = localStorage.getItem("token"); // Retrieve token from localStorage for authorization
    if (!token) {
      setErrorMessage("Unauthorized. Please login.");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8083/api/booking/cancel/${bookingId}`, {
        method: "DELETE", // Using DELETE method for cancellation
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to cancel booking. Please try again.");
      }

      // Since the response is plain text, use .text() instead of .json()
      const data = await response.text(); // Use .text() to handle plain text
      setStatusMessage(data); // Display the success message from the backend
      setErrorMessage(""); // Clear any previous error message
    } catch (error) {
      setStatusMessage("");
      setErrorMessage(error.message);
    }
  };

  const handleGoToDashboard = () => {
    navigate("/dashboard"); // Navigate to dashboard when the button is clicked
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow-md max-w-md w-full">
        <h2 className="text-2xl font-bold mb-4 text-center">Cancel Booking</h2>
        <form onSubmit={handleCancelBooking} className="mb-4">
          <div className="mb-4">
            <label htmlFor="bookingId" className="block text-sm font-semibold">
              Enter Booking ID
            </label>
            <input
              id="bookingId"
              type="text"
              value={bookingId}
              onChange={(e) => setBookingId(e.target.value)}
              className="w-full p-2 border rounded mt-1"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700"
          >
            Cancel Booking
          </button>
        </form>

        {statusMessage && (
          <div className="mt-4 text-green-600">{statusMessage}</div>
        )}

        {errorMessage && (
          <div className="mt-4 text-red-600">{errorMessage}</div>
        )}

        <div className="mt-4">
          <button
            onClick={handleGoToDashboard}
            className="w-full bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-700"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}

export default CancelBookingForm;
