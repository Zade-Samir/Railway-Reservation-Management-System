import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function NewBooking() {
  const [formData, setFormData] = useState({
    userEmail: "",
    trainNumber: "",
    trainName: "",
    source: "",
    destination: "",
    journeyDate: "",
    numberOfTickets: 1,
  });

  const [bookingId, setBookingId] = useState(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    try {
      const response = await fetch("http://localhost:8083/api/booking/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Booking failed. Please try again.");
      }

      const data = await response.json();
      setBookingId(data.id);  // Assuming the response contains the booking ID as 'id'
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-xl mx-auto mt-10 p-6 bg-white shadow rounded">
      <h2 className="text-2xl font-bold mb-4 text-center">New Booking</h2>

      {error && <p className="text-red-500 mb-4">{error}</p>}
      {bookingId ? (
        <div className="text-center">
          <p className="text-green-600 font-semibold mb-4">
            Booking successful! Your Booking ID is: <strong>{bookingId}</strong>
          </p>
          <button
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            onClick={() => navigate("/dashboard")}
          >
            Back to Dashboard
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          {[
            ["userEmail", "Email"],
            ["trainNumber", "Train Number"],
            ["trainName", "Train Name"],
            ["source", "Source"],
            ["destination", "Destination"],
            ["journeyDate", "Journey Date (YYYY-MM-DD)"],
            ["numberOfTickets", "Number of Tickets"],
          ].map(([key, label]) => (
            <div key={key}>
              <label className="block font-semibold mb-1">{label}</label>
              <input
                type={key === "numberOfTickets" ? "number" : "text"}
                name={key}
                value={formData[key]}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border rounded"
              />
            </div>
          ))}

          <button
            type="submit"
            className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
          >
            Submit Booking
          </button>
        </form>
      )}
    </div>
  );
}
