import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

function UserBookings() {
  const { email } = useParams();
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token"); // get token from login
    if (!token) {
      setError("Unauthorized. Please login.");
      return;
    }

    fetch(`http://localhost:8083/api/booking/user/${email}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Error fetching bookings");
        return res.json();
      })
      .then(setBookings)
      .catch((err) => setError(err.message));
  }, [email]);

  if (error) return <p className="text-red-600 text-center">{error}</p>;

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center py-10">
      <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-4xl">
        <h2 className="text-2xl font-semibold text-blue-600 mb-6 text-center">
          Bookings for {email}
        </h2>
        {bookings.length === 0 ? (
          <p className="text-center text-gray-500">No bookings found.</p>
        ) : (
          <table className="min-w-full table-auto text-gray-700 mb-6">
            <thead>
              <tr className="bg-blue-600 text-white">
                <th className="px-6 py-4 text-left">Train Name</th>
                <th className="px-6 py-4 text-left">Source</th>
                <th className="px-6 py-4 text-left">Destination</th>
                <th className="px-6 py-4 text-left">Journey Date</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr
                  key={booking.id}
                  className="border-b hover:bg-gray-50 cursor-pointer"
                >
                  <td className="px-6 py-4">{booking.trainName}</td>
                  <td className="px-6 py-4">{booking.source}</td>
                  <td className="px-6 py-4">{booking.destination}</td>
                  <td className="px-6 py-4">{booking.journeyDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div className="text-center">
          <button
            onClick={() => navigate("/dashboard")}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}

export default UserBookings;
