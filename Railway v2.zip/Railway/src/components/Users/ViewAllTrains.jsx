import React, { useState } from "react";

export default function ViewAllTrains() {
  const [trains, setTrains] = useState([]);
  const [error, setError] = useState("");
  const [trainNumber, setTrainNumber] = useState("");
  const [searchResult, setSearchResult] = useState(null);

  // Fetch all trains only on button click
  const fetchAllTrains = async () => {
    try {
      const response = await fetch("http://localhost:8084/api/train");
      if (!response.ok) {
        throw new Error("Failed to fetch train data");
      }
      const data = await response.json();
      setTrains(data);
      setSearchResult(null); // clear previous result
      setError("");
    } catch (err) {
      setError(err.message);
    }
  };

  // Fetch train by number
  const handleSearch = async (e) => {
    e.preventDefault();
    setError("");
    setSearchResult(null);
    setTrains([]); // clear previous all-train data

    if (!trainNumber) {
      setError("Please enter a train number");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8084/api/train/${trainNumber}`);
      if (!response.ok) {
        throw new Error("Train not found");
      }
      const data = await response.json();
      setSearchResult([data]); // Wrap in array for consistency
    } catch (err) {
      setError(err.message);
    }
  };

  const displayedTrains = searchResult || trains;

  return (
    <div className="max-w-6xl mx-auto mt-10 p-6 bg-white rounded shadow">
      <h2 className="text-3xl font-bold mb-6 text-center">Train Information</h2>

      {/* Buttons and Form */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
        <button
          onClick={fetchAllTrains}
          className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          View All Trains
        </button>

        <form onSubmit={handleSearch} className="flex gap-2 items-center">
          <input
            type="text"
            placeholder="Enter Train Number"
            value={trainNumber}
            onChange={(e) => setTrainNumber(e.target.value)}
            className="px-4 py-2 border rounded w-64"
          />
          <button
            type="submit"
            className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            View by Train Number
          </button>
        </form>
      </div>

      {error && <p className="text-red-600 text-center mb-4">{error}</p>}

      {/* Display Table */}
      {displayedTrains.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm border">
            <thead className="bg-gray-200">
              <tr>
                <th className="px-4 py-2 border">Train Number</th>
                <th className="px-4 py-2 border">Train Name</th>
                <th className="px-4 py-2 border">Source</th>
                <th className="px-4 py-2 border">Destination</th>
                <th className="px-4 py-2 border">Seats Available</th>
              </tr>
            </thead>
            <tbody>
              {displayedTrains.map((train, index) => (
                <tr key={index} className="text-center border-t">
                  <td className="px-4 py-2 border">{train.trainNumber}</td>
                  <td className="px-4 py-2 border">{train.trainName}</td>
                  <td className="px-4 py-2 border">{train.source}</td>
                  <td className="px-4 py-2 border">{train.destination}</td>
                  <td className="px-4 py-2 border">{train.availableSeats}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
