import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="w-full min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden text-black rounded-lg mx-auto px-4 sm:px-16 py-20">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-12 items-center">
          {/* Text and Button */}
          <div className="text-center sm:text-left space-y-6">
            <h2 className="text-4xl sm:text-5xl font-extrabold text-blue-900 leading-tight">
              View All Trains
            </h2>
            <p className="text-gray-600 text-lg">
              Explore a complete list of trains available for booking. Fast, reliable, and always up-to-date!
            </p>
            <Link
              to="/viewAllTrains"
              className="inline-flex items-center justify-center px-6 py-3 text-white font-semibold bg-orange-700 rounded-lg shadow hover:bg-orange-800 focus:outline-none focus:ring-4 focus:ring-orange-300 transition"
            >
              <svg
                fill="white"
                width="24"
                height="24"
                xmlns="http://www.w3.org/2000/svg"
                fillRule="evenodd"
                clipRule="evenodd"
                className="mr-2"
              >
                <path d="M1.571 23.664l10.531-10.501 3.712 3.701-12.519 6.941c-.476.264-1.059.26-1.532-.011l-.192-.13zm9.469-11.56l-10.04 10.011v-20.022l10.04 10.011zm6.274-4.137l4.905 2.719c.482.268.781.77.781 1.314s-.299 1.046-.781 1.314l-5.039 2.793-4.015-4.003 4.149-4.137zm-15.854-7.534c.09-.087.191-.163.303-.227.473-.271 1.056-.275 1.532-.011l12.653 7.015-3.846 3.835-10.642-10.612z" />
              </svg>
              View Trains
            </Link>
          </div>

          {/* Image */}
          <div className="flex justify-center">
            <img
              className="w-80 sm:w-[400px] rounded-xl shadow-lg"
              src="https://gofloaters.com/work-from-anywhere-toolkit/assets/images/remote2.png"
              alt="Train visual"
            />
          </div>
        </div>
      </section>

      {/* Second Image */}
      <div className="flex justify-center mt-8 sm:mt-12">
        <img
          className="w-48 sm:w-96 rounded-xl shadow-md"
          src="https://globalvoices.org/wp-content/uploads/2021/05/Remote1-1.png"
          alt="Remote work illustration"
        />
      </div>

      {/* Footer Heading */}
      <h1 className="text-center text-3xl sm:text-5xl py-12 font-semibold text-blue-800">
        Discover. Book. Ride.
      </h1>
    </div>
  );
}
